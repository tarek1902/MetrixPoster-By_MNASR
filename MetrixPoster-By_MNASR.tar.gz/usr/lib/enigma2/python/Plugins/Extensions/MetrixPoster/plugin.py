#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################
# # __created_by__ = "MNASR"    # #
###################################
from __future__ import absolute_import, print_function

import os
import sys
from threading import Thread

from Plugins.Plugin import PluginDescriptor
# from Components.PluginComponent import plugins
from Components.config import (
    config, ConfigSubsection, ConfigOnOff, ConfigYesNo,
    ConfigText, getConfigListEntry, configfile, ConfigNothing, NoSave
)
from Components.ConfigList import ConfigListScreen
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Screens.MessageBox import MessageBox

from enigma import getDesktop, eTimer

# Import the Substitute Screen
from .MetrixHDSP_Substitute import MetrixTitleSubstituteScreen

# Python 2/3 Compatibility
PY3 = sys.version_info[0] >= 3
if PY3:
    from urllib.request import urlopen, urlretrieve
else:
    from urllib2 import urlopen
    from urllib import urlretrieve

# XML parser (cElementTree is faster but deprecated in Py3.3+; fallback to ElementTree)
try:
    from xml.etree.cElementTree import parse as ET_parse
    import xml.etree.cElementTree as ET
except ImportError:
    from xml.etree.ElementTree import parse as ET_parse
    import xml.etree.ElementTree as ET

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixPoster"
TMDB_API_FILE = os.path.join(PLUGIN_PATH, "tmdb_api")
PLUGIN_VERSION = "1.0"
VERSION_URL = "https://raw.githubusercontent.com/popking159/skins/main/metrix_skinparts/version.txt"
UPDATE_TAR_URL = "https://raw.githubusercontent.com/popking159/skins/main/metrix_skinparts/metrix_skinparts_mnasr.tar.gz"

# =========================================================
# Screen resolution detection (used for skin and icon selection)
# =========================================================
try:
    ScreenWidth = getDesktop(0).size().width()
except Exception:
    ScreenWidth = 720

# Map pixel width to skin folder name and plugin icon
if ScreenWidth >= 2560:
    ScreenWidth = '1440'
    plugin_icon = "ico/logo_2K.png"
elif ScreenWidth >= 1920:
    ScreenWidth = '1080'
    plugin_icon = "ico/logo_FHD.png"
else:
    ScreenWidth = '720'
    plugin_icon = "ico/logo_HD.png"

# =========================================================
# Skin XML loading
# =========================================================
try:
    skin_file = os.path.join(PLUGIN_PATH, 'skin', '%s.xml' % ScreenWidth)
    plugin_skin = ET_parse(skin_file).getroot()
except Exception as _e:
    print("[MetrixPoster] Error loading skin: %s" % str(_e))
    plugin_skin = None


def getSkin(skinName):
    if plugin_skin is not None:
        try:
            skin_element = plugin_skin.find('.//screen[@name="%s"]' % skinName)
            if skin_element is not None:
                if PY3:
                    return ET.tostring(skin_element, encoding='unicode', method='xml')
                else:
                    data = ET.tostring(
                        skin_element, encoding='utf-8', method='xml')
                    if isinstance(data, bytes) and data.startswith(b"<?xml"):
                        data = data[data.find(b'>') + 1:].lstrip()
                    return data
        except Exception as _e:
            print("[MetrixPoster] Error getting skin %s: %s" %
                  (skinName, str(_e)))
    return ''


# --- Initialize Configurations under MetrixHDSP ---
if not hasattr(config.plugins, "MetrixHDSP"):
    config.plugins.MetrixHDSP = ConfigSubsection()

# Live Events
config.plugins.MetrixHDSP.rating_source = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.show_poster = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.show_backdrop = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.show_logo = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.genre_source = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.info_display_mode = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.info_parental_mode = ConfigOnOff(default=True)

# Enhanced Movie Center
config.plugins.MetrixHDSP.xemc_poster = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.xemc_backdrop = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.xemc_logo = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.xemc_info = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.xemc_star = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.xemc_cast = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.xemc_parental = ConfigOnOff(default=True)

# TMDB API Configuration (Reverted to the actual key)
config.plugins.MetrixHDSP.actapi = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.tmdb = ConfigOnOff(default=True)
config.plugins.MetrixHDSP.load_tmdb_api = ConfigYesNo(default=False)
config.plugins.MetrixHDSP.tmdb_api = ConfigText(
    default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)


def check_and_import_tmdb_key():
    """Reads tmdb_api from text file inside plugin folder if option is enabled."""
    if config.plugins.MetrixHDSP.load_tmdb_api.value:
        if os.path.exists(TMDB_API_FILE):
            try:
                with open(TMDB_API_FILE, "r") as f:
                    key = f.read().strip()
                    if key:
                        config.plugins.MetrixHDSP.tmdb_api.value = key
                        return True
            except Exception as e:
                print("[MetrixPoster] Error reading tmdb_api file:", str(e))
    return False


class MetrixPosterSetup(ConfigListScreen, Screen):
    fallback_skin = """
        <screen name="MetrixPosterSetup" position="center,center" size="850,650" title="MetrixPoster Setup">
            <widget name="config" position="20,20" size="810,540" scrollbarMode="showOnDemand" />
            <widget name="key_red" position="20,580" size="140,40" backgroundColor="red" font="Regular;20" halign="center" valign="center" />
            <widget name="key_green" position="170,580" size="140,40" backgroundColor="green" font="Regular;20" halign="center" valign="center" />
            <widget name="key_yellow" position="320,580" size="140,40" backgroundColor="yellow" font="Regular;20" halign="center" valign="center" />
            <widget name="key_blue" position="470,580" size="140,40" backgroundColor="blue" font="Regular;20" halign="center" valign="center" />
            <widget name="status" position="620,580" size="210,40" font="Regular;18" halign="right" valign="center" transparent="1" />
        </screen>
    """

    def __init__(self, session):
        loaded_skin = getSkin("MetrixPosterSetup")
        if loaded_skin:
            self.skin = loaded_skin
        else:
            self.skin = self.fallback_skin

        Screen.__init__(self, session)

        # Dynamically override the XML title
        self.setTitle("MetrixPoster Setup - MetrixPoster v" + PLUGIN_VERSION)

        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)

        self["key_red"] = Button("Cancel")
        self["key_green"] = Button("Save")
        self["key_yellow"] = Button("Check Update")
        self["key_blue"] = Button("EPG Match")
        self["status"] = Label("Checking...")

        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "EPGSelectActions"], {
            "red": self.cancel,
            "green": self.save,
            "yellow": self.manualCheckUpdate,
            "blue": self.openSubstitute,
            "info": self.openSubstitute,
            "epg": self.openSubstitute,
            "save": self.save,
            "cancel": self.cancel,
            "ok": self.save,
        }, -2)

        check_and_import_tmdb_key()
        self.createSetup()

        # Background Auto-Update Check
        self.online_version = None
        self.apply_timer = eTimer()
        self.apply_timer.callback.append(self.applyUpdateStatus)
        Thread(target=self._checkUpdateThread).start()

    def _checkUpdateThread(self):
        try:
            response = urlopen(VERSION_URL, timeout=3)
            self.online_version = response.read().decode('utf-8').strip()
        except Exception:
            self.online_version = "ERR"
        # Trigger the GUI update safely
        self.apply_timer.start(0, True)

    def applyUpdateStatus(self):
        if self.online_version == "ERR":
            self["status"].setText("Check failed!")
        elif self.online_version and self.online_version > PLUGIN_VERSION:
            self["status"].setText("Update Found")
        else:
            self["status"].setText("Up to Date")

    def createSetup(self):
        self.list = []

        # --- Live Events ---
        section = '-------------------------( Live EVENTS )------------------------'
        self.list.append(getConfigListEntry(section, NoSave(ConfigNothing())))
        self.list.append(getConfigListEntry(
            "Show Poster", config.plugins.MetrixHDSP.show_poster))
        self.list.append(getConfigListEntry(
            "Show Backdrop", config.plugins.MetrixHDSP.show_backdrop))
        self.list.append(getConfigListEntry(
            "Show Logo", config.plugins.MetrixHDSP.show_logo))
        self.list.append(getConfigListEntry(
            "Rating Source Info", config.plugins.MetrixHDSP.rating_source))
        self.list.append(getConfigListEntry(
            "Genre Source Info", config.plugins.MetrixHDSP.genre_source))
        self.list.append(getConfigListEntry(
            "Show Display Info", config.plugins.MetrixHDSP.info_display_mode))
        self.list.append(getConfigListEntry(
            "Show Parental Rating", config.plugins.MetrixHDSP.info_parental_mode))

        # --- Enhanced Movie Center ---
        section = '--------------------( Enhanced Movie Center )-------------------'
        self.list.append(getConfigListEntry(section, NoSave(ConfigNothing())))
        self.list.append(getConfigListEntry(
            "XEMC Poster", config.plugins.MetrixHDSP.xemc_poster))
        self.list.append(getConfigListEntry(
            "XEMC Backdrop", config.plugins.MetrixHDSP.xemc_backdrop))
        self.list.append(getConfigListEntry(
            "XEMC Logo", config.plugins.MetrixHDSP.xemc_logo))
        self.list.append(getConfigListEntry(
            "XEMC Info", config.plugins.MetrixHDSP.xemc_info))
        self.list.append(getConfigListEntry(
            "XEMC Star Rating", config.plugins.MetrixHDSP.xemc_star))
        self.list.append(getConfigListEntry("XEMC Cast Info",
                         config.plugins.MetrixHDSP.xemc_cast))
        self.list.append(getConfigListEntry(
            "XEMC Parental Rating", config.plugins.MetrixHDSP.xemc_parental))

        # --- TMDB API Configuration ---
        section = '-------------------( TMDB API CONFIGURATION )-------------------'
        self.list.append(getConfigListEntry(section, NoSave(ConfigNothing())))
        self.list.append(getConfigListEntry(
            "Activate API Services", config.plugins.MetrixHDSP.actapi))
        self.list.append(getConfigListEntry(
            "Enable TMDB Provider", config.plugins.MetrixHDSP.tmdb))
        self.list.append(getConfigListEntry(
            "Import TMDB Key from 'tmdb_api' File", config.plugins.MetrixHDSP.load_tmdb_api))
        self.list.append(getConfigListEntry(
            "TMDB API Key", config.plugins.MetrixHDSP.tmdb_api))

        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def keySelect(self):
        ConfigListScreen.keySelect(self)
        if self["config"].getCurrent()[1] == config.plugins.MetrixHDSP.load_tmdb_api:
            if check_and_import_tmdb_key():
                self.createSetup()

    def openSubstitute(self):
        self.session.open(MetrixTitleSubstituteScreen)

    def save(self):
        check_and_import_tmdb_key()
        for x in self["config"].list:
            if hasattr(x[1], "save"):
                x[1].save()
        configfile.save()
        self.close()

    def cancel(self):
        for x in self["config"].list:
            if hasattr(x[1], "cancel"):
                x[1].cancel()
        self.close()

    def manualCheckUpdate(self):
        self["status"].setText("Checking...")
        try:
            response = urlopen(VERSION_URL, timeout=10)
            online_version = response.read().decode('utf-8').strip()

            if online_version > PLUGIN_VERSION:
                self.session.openWithCallback(
                    self.startUpdate,
                    MessageBox,
                    "New version %s available!\nDo you want to update now?" % online_version,
                    MessageBox.TYPE_YESNO
                )
            else:
                self["status"].setText("Up to Date")
                self.session.open(MessageBox, "You are using the latest version (%s)." %
                                  PLUGIN_VERSION, MessageBox.TYPE_INFO)
        except Exception as e:
            self["status"].setText("Check failed!")
            self.session.open(MessageBox, "Failed to check for updates: %s" % str(
                e), MessageBox.TYPE_ERROR)

    def startUpdate(self, answer):
        if answer:
            self["status"].setText("Updating...")
            tmp_file = "/tmp/metrix_skinparts_mnasr.tar.gz"
            try:
                urlretrieve(UPDATE_TAR_URL, tmp_file)
                os.system("tar -xzf %s -C /" % tmp_file)
                if os.path.exists(tmp_file):
                    os.remove(tmp_file)
                self.session.open(
                    MessageBox, "Update installed successfully!\nPlease restart Enigma2 GUI.", MessageBox.TYPE_INFO)
                self.close()
            except Exception as e:
                self["status"].setText("Update failed!")
                self.session.open(MessageBox, "Update failed: %s" %
                                  str(e), MessageBox.TYPE_ERROR)


def main(session, **kwargs):
    session.open(MetrixPosterSetup)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="MetrixPoster Setup",
            description="Control MetrixHDSP poster, backdrop, logo settings and TMDB API",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=plugin_icon,
            fnc=main
        )
    ]
